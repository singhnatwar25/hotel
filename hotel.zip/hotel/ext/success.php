<!-- razorpay success page  -->
  <?php

//   $razorpay_signature = $_POST['razorpay_signature'];
//   $razorpay_payment_id = $_POST['razorpay_payment_id'];
//   $razorpay_order_id = $_POST['razorpay_order_id'];
//   $razorpay_payment_status = $_POST['razorpay_payment_status'];


    header('Location: index.php');
  ?>