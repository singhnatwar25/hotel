<!-- Razorpay php integration config file -->
<?php
  define('BASE_URL', 'http://localhost:8080');
  define('API_KEY', 'rzp_test_5OFGvIb0D4UiM9');
  define('API_SECRET', 'mCOPoNDgs97jvZGgrC51nE1d');
  define('COMPANY_NAME', 'NATWAR');
  define('COMPANY_LOGO','img/logo1.png');
  

  ?>