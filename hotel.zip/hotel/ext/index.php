<?php
 
     header("Location: ../");
     exit;   
    
 ?>